MODDIR=${0%/*}
BUSYBOXDIR=/data/adb/magisk/busybox
export PATH=/data/adb/magisk/busybox:$PATH
dozefile=/data/media/0/Android/yc/uperf/freezer.conf
	if [[ $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) != "true" ]]; then
	
    function app (){
    cat $dozefile | sed '/^[[:space:]]*$/d;/^#/d;s/+//g;/whitelist.*\"/d;s/\"//g'
    }

for i in `dumpsys deviceidle whitelist | cut -d ',' -f 2 | sed '/com.android.providers.downloads/d;/com.android.phone/d '`;do
		dumpsys deviceidle whitelist -$i
	done
	
	for i in $(app);do dumpsys deviceidle whitelist +$i ;done
	
	is_empty_dir(){
   return `ls -A $1 | wc -w`
}
 
folder="/data/media/0/"
 
for file in `ls $folder`
do

if is_empty_dir $folder"/"$file  
then
    echo 3 > /proc/sys/vm/drop_caches
    echo 1 > /proc/sys/vm/compact_memory
    rm -rf $folder"/"$file
else
	echo 3 > /proc/sys/vm/drop_caches
	echo 1 > /proc/sys/vm/compact_memory
fi
done

	fi