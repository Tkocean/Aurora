MODDIR=${0%/*}
BUSYBOXDIR=/data/adb/magisk/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
test -e /data/cron.d && {
	chmod -R 777 /data/cron.d
	until $(dumpsys deviceidle get screen) ;do
		sleep 4
	done
	for i in /data/cron.d/*.sh ;do
		$i 2> /dev/null
	done
}

crond -c /data/cron.d

setprop net.hostname 'Google Pixel 6 Pro'
rm -f /data/clash.old
rm -rf /data/vendor/wlan_log
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs
rm -rf /data/system/dropbox
rm -rf /data/system/procstats
rm -rf /data/system/usagestats/0

sleep 20
touch /data/adb/modules/Clash_For_Magisk/disable
#chattr +i /data/media/0/Android/data/com.tencent.mm/MicroMsg/CheckResUpdate
#chattr +i /data/data/com.tencent.mm/shared_prefs/hardcoder_setting.xml
rm -f /cache/magisk.log*
rm -f /data/clash/run/kernel.old.log
sleep 5
rm -f /data/adb/modules/Clash_For_Magisk/disable
setprop net.hostname 'Google Pixel 6 Pro'
echo ·····ViEW has been mounted to zygote  > /cache/magisk.log

done