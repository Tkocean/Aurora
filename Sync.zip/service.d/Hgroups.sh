MODDIR=${0%/*}
sleep 60
module=/data/adb/modules/zygisk_lsposed/module.prop
conf="/data/media/0/Android/yc/uperf/freezer.conf"
model=$(sed '/^mod=/!d;s/.*=//' $conf)
processrate=$(sed '/^CPU=/!d;s/.*=//' $conf)
freezer=$(mount | grep cgroup | grep freezer | cut -d ' ' -f3 | tail -n 1)
cpuctl=$(mount | grep cgroup | grep cpuctl | cut -d ' ' -f3 | tail -n 1)
sysfs="/sys/fs/cgroup"
miancpuctl() {
	mkdir $cpuctl/Tkocean
	if [[ -d "$cpuctl/Tkocean" ]]; then
		sed -i "s/主张：.*/主张：[ViEW has init injected 😋 ] $(date '+%y %m.%d %T') /g" $module
		while read document; do
			process=$(pidof "$document" | cut -d ' ' -f1)
			if [[ $process != 0 ]]; then
				echo $process >>$cpuctl/Tkocean/cgroup.procs
			fi
		done <$conf
		echo $processrate >$cpuctl/Tkocean/cpu.rt_period_us
		echo 0.01 >$cpuctl/Tkocean/cpu.uclamp.max
		echo 0.00 >$cpuctl/Tkocean/cpu.uclamp.min
		echo 0 >$cpuctl/Tkocean/cpu.shares
	else
		sed -i "s/主张：.*/主张：[ViEW has init injected 😋 ] $(date '+%y %m.%d %T') /g" $module
		exit
	fi
}
mianfreezer() {
	if [[ -d "$sysfs" ]]; then
		if [[ $(mount | grep $sysfs) == "" ]]; then
			mount -t tmpfs HCcgroup /sys/fs/cgroup
		fi
		if [[ ! -d "$sysfs/freezer" ]]; then
			mkdir $sysfs/freezer
			mount -t cgroup -o freezer HCfreezer $sysfs/freezer
		fi
	fi
	freezer=$(mount | grep cgroup | grep freezer | cut -d ' ' -f3 | tail -n 1)
	mkdir $freezer/Tkocean
	if [[ -d "$freezer/Tkocean" ]]; then
		sed -i "s/主张：.*/主张：[ViEW has init injected 😋 ] $(date '+%y %m.%d %T') /g" $module
		while read document; do
			process=$(pidof "$document" | cut -d ' ' -f1)
			if [[ $process != 0 ]]; then
				echo $process >>$freezer/Tkocean/cgroup.procs
			fi
		done <$conf
		echo FROZEN >$freezer/Tkocean/freezer.state
	else
		sed -i "s/主张：.*/主张：freezer失败/g" $module
		exit
	fi
}
mianfreezercpuctl() {
	if [[ -d "$sysfs" ]]; then
		if [[ $(mount | grep $sysfs) == "" ]]; then
			mount -t tmpfs HCcgroup /sys/fs/cgroup
		fi
		if [[ ! -d "$sysfs/freezer" ]]; then
			mkdir $sysfs/freezer
			mount -t cgroup -o freezer HCfreezer $sysfs/freezer
		fi
	fi
	freezer=$(mount | grep cgroup | grep freezer | cut -d ' ' -f3 | tail -n 1)
	mkdir $freezer/Tkocean
	if [[ -d "$freezer/Tkocean" ]]; then
		sed -i "s/主张：.*/主张：[ViEW has init injected 😋 ] $(date '+%y %m.%d %T') /g" $module
		while read document; do
			process=$(pidof "$document" | cut -d ' ' -f1)
			if [[ $process != 0 ]]; then
				echo $process >>$freezer/Tkocean/cgroup.procs
			fi
		done <$conf
		echo FROZEN >$freezer/Tkocean/freezer.state
	else
		mkdir $cpuctl/Tkocean
		if [[ -d "$cpuctl/Tkocean" ]]; then
			sed -i "s/主张：.*/主张：cpuctl成功/g" $module
			while read document; do
				process=$(pidof "$document" | cut -d ' ' -f1)
				if [[ $process != 0 ]]; then
					echo $process >>$cpuctl/Tkocean/cgroup.procs
				fi
			done <$conf
			echo $processrate >$cpuctl/Tkocean/cpu.rt_period_us
			echo 0.01 >$cpuctl/Tkocean/cpu.uclamp.max
			echo 0.00 >$cpuctl/Tkocean/cpu.uclamp.min
			echo 0 >$cpuctl/Tkocean/cpu.shares
		else
			sed -i "s/主张：.*/主张：默认freezer和cpuctl都失败/g" $module
			exit
		fi
	fi
}
case $model in
模式1 | 1)
	mianfreezercpuctl
	;;
模式2 | 2)
	mianfreezer
	;;
模式3 | 3)
	miancpuctl
	;;
*)
	sed -i "s/主张：.*/主张：配置文件自定义模式出错/g" $module
	exit 1
	;;
esac