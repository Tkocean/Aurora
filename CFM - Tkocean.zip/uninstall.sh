Clash_data_dir="/data/clash"

rm_data() {
    rm -rf ${Clash_data_dir}
}

rm_data